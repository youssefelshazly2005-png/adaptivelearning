"""Structural validation is deliberately separate from expert approval."""
import json
import re
from collections import Counter
from graphlib import TopologicalSorter
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def validate(graph,questions):
    concepts=graph['concepts'];ids=[c['concept_id'] for c in concepts];known=set(ids)
    if len(ids)!=len(known):raise ValueError('Duplicate concept ID')
    parents={c:[] for c in ids};pairs=set()
    for e in graph['edges']:
        p,c=e['prerequisite_id'],e['concept_id']
        if p not in known or c not in known or p==c:raise ValueError('Invalid edge endpoint')
        if (p,c) in pairs:raise ValueError('Duplicate edge')
        pairs.add((p,c));parents[c].append(p)
    order=list(TopologicalSorter(parents).static_order())
    qids=set();counts=Counter();difficulty={c:Counter() for c in ids}
    for q in questions:
        if q['question_id'] in qids:raise ValueError('Duplicate question ID')
        qids.add(q['question_id']);cid=q['concept_id']
        if cid not in known:raise ValueError('Unknown question concept')
        counts[cid]+=1;difficulty[cid][q['difficulty']]+=1
        if set(q['prerequisite_ids'])!=set(parents[cid]):raise ValueError('Question/graph prerequisites disagree')
        if q['correct_option'] not in 'ABCD' or len(q['correct_option'])!=1:raise ValueError('Invalid answer key')
        for lang in ['ar','en']:
            t=q['translations'][lang]
            if not t['question_text'].strip() or not t['explanation'].strip():raise ValueError('Missing translation')
            if set(t['options'])!=set('ABCD') or len(set(t['options'].values()))!=4:raise ValueError('Invalid or repeated options')
        if not re.search('[\u0600-\u06ff]',q['translations']['ar']['question_text']):raise ValueError('Arabic prompt missing')
    if any(counts[c]!=5 or difficulty[c]!=Counter(Easy=2,Medium=2,Hard=1) for c in ids):raise ValueError('Coverage blueprint mismatch')
    if graph['status']=='gold' and not graph['supervisor_approved']:raise ValueError('Gold graph requires signoff')
    return {'concepts':len(ids),'edges':len(pairs),'questions':len(qids),'roots':[c for c in ids if not parents[c]],
            'topological_order':order,'expert_review':'pending','template_questions':sum('template_item' in q['quality_flags'] for q in questions)}

if __name__=='__main__':
    result=validate(json.loads((ROOT/'data/graph.json').read_text()),json.loads((ROOT/'data/questions_bilingual.json').read_text()))
    (ROOT/'reports/validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
