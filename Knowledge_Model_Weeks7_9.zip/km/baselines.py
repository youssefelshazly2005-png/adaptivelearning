"""Offline shared-protocol BKT and upstream pyKT DKT benchmark; no telemetry."""
import argparse
import copy
import hashlib
import importlib.util
import json
import platform
import subprocess
import time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.metrics import roc_auc_score, log_loss, accuracy_score


def read_sequences(path):
    df=pd.read_csv(path,dtype={'uid':str})
    out=[]
    for row in df.itertuples():
        q=np.array([int(x) for x in row.concepts.split(',')]);r=np.array([int(x) for x in row.responses.split(',')])
        if len(q)!=len(r):raise ValueError('Concept/response length mismatch')
        mask=q!=-1;q=q[mask];r=r[mask]
        if len(q)<2:continue
        if (q<0).any() or not np.isin(r,[0,1]).all():raise ValueError('Invalid IDs/responses')
        out.append((str(row.uid),getattr(row,'fold',-1),q,r))
    return out


def arrays(rows,maxlen=200):
    q=np.zeros((len(rows),maxlen),dtype=np.int64);r=q.copy();mask=np.zeros_like(q,dtype=bool)
    for i,(_,_,qs,rs) in enumerate(rows):
        if len(qs)>maxlen:raise ValueError('Preprocess sequences to at most 200 interactions')
        q[i,:len(qs)]=qs;r[i,:len(rs)]=rs;mask[i,1:len(qs)]=True
    return q,r,mask


def bkt_predict(params,data,num_c):
    l0,learn,guess,slip=params;q,r,mask=data
    state=np.full((len(q),num_c),l0);idx=np.arange(len(q));out=np.zeros(q.shape)
    # Prediction precedes observation; learning follows posterior update. No forgetting.
    for t in range(q.shape[1]):
        prior=state[idx,q[:,t]];p=prior*(1-slip)+(1-prior)*guess;out[:,t]=p
        posterior=np.where(r[:,t]==1,prior*(1-slip)/p,prior*slip/(1-p))
        state[idx,q[:,t]]=posterior+(1-posterior)*learn
    return out[mask]


def metrics(y,p):
    return {'auc':float(roc_auc_score(y,p)) if len(np.unique(y))==2 else None,
            'log_loss':float(log_loss(y,p,labels=[0,1])),
            'accuracy':float(accuracy_score(y,p>=.5)),'predictions':len(y)}


def run(args):
    import torch
    torch.set_num_threads(args.threads);torch.manual_seed(args.seed);np.random.seed(args.seed)
    torch.use_deterministic_algorithms(True)
    root=Path(args.pykt_root).resolve();data=Path(args.data_dir).resolve();out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    trainfile=data/'train_valid_sequences.csv';testfile=data/'test_sequences.csv'
    rows=read_sequences(trainfile);test=read_sequences(testfile)
    train=[x for x in rows if x[1]!=args.valid_fold];valid=[x for x in rows if x[1]==args.valid_fold]
    sets=[{x[0] for x in a} for a in [train,valid,test]]
    if any(sets[i]&sets[j] for i in range(3) for j in range(i)):raise ValueError('Student leakage across splits')
    if not all([train,valid,test]):raise ValueError('Empty split')
    # Vocabulary metadata may include held-out skills; no held-out outcomes are used for fitting.
    num_c=max(int(x[2].max()) for x in train+valid+test)+1
    tr,va,te=[arrays(a) for a in [train,valid,test]]
    ytr=tr[1][tr[2]];yv=va[1][va[2]];yt=te[1][te[2]]
    start=time.time()
    fit=minimize(lambda p:log_loss(ytr,bkt_predict(p,tr,num_c),labels=[0,1]),
                 [.2,.1,.2,.1],method='L-BFGS-B',bounds=[(.001,.999),(.001,.8),(.001,.49),(.001,.49)],
                 options={'maxiter':args.bkt_iterations})
    bp=bkt_predict(fit.x,te,num_c)
    bkt={'implementation':'local fitted four-parameter BKT; pyKT has no BKT implementation',
         'parameters':dict(zip(['initial','learn','guess','slip'],fit.x.tolist())),
         'optimizer_success':bool(fit.success),'optimizer_message':str(fit.message),
         'valid':metrics(yv,bkt_predict(fit.x,va,num_c)),'test':metrics(yt,bp),'seconds':time.time()-start}
    print('BKT',bkt,flush=True)
    # Import the exact upstream module directly; avoids optional unrelated models and wandb imports.
    modelpath=root/'pykt/models/dkt.py'
    spec=importlib.util.spec_from_file_location('upstream_pykt_dkt',modelpath);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    model=module.DKT(num_c,args.hidden,.1);optimizer=torch.optim.Adam(model.parameters(),lr=.001)
    tensors=[tuple(torch.from_numpy(a) for a in d) for d in [tr,va,te]]
    def predict(d):
        model.eval();ys=[];ps=[]
        with torch.no_grad():
            for begin in range(0,len(d[0]),128):
                q,r,m=[a[begin:begin+128] for a in d]
                p=model(q[:,:-1],r[:,:-1]).gather(2,q[:,1:].unsqueeze(-1)).squeeze(-1)
                ys.extend(r[:,1:][m[:,1:]].tolist());ps.extend(p[m[:,1:]].tolist())
        return np.array(ys),np.array(ps)
    best=None;bestloss=float('inf');history=[];start=time.time()
    for epoch in range(args.epochs):
        model.train();order=torch.randperm(len(tr[0]));total=0.
        for ids in order.split(128):
            q,r,m=[a[ids] for a in tensors[0]];optimizer.zero_grad()
            p=model(q[:,:-1],r[:,:-1]).gather(2,q[:,1:].unsqueeze(-1)).squeeze(-1)
            loss=torch.nn.functional.binary_cross_entropy(p[m[:,1:]],r[:,1:][m[:,1:]].float())
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5);optimizer.step();total+=float(loss.detach())
        y,p=predict(tensors[1]);v=metrics(y,p);history.append({'epoch':epoch+1,'valid':v})
        if v['log_loss']<bestloss:bestloss=v['log_loss'];best=copy.deepcopy(model.state_dict())
        print('DKT',history[-1],flush=True)
    model.load_state_dict(best);y,dp=predict(tensors[2]);assert np.array_equal(y,yt)
    torch.save(best,out/'dkt.pt')
    result={'dataset':args.dataset,'seed':args.seed,'protocol':'pyKT provided student-disjoint folds; validation fold 0; first interaction excluded; chunks reset state for BOTH models; no padding scored',
       'scope':'single seed CPU baseline, no hyperparameter sweep; not a published benchmark replication',
       'split_students':dict(zip(['train','validation','test'],map(len,sets))),
       'split_sequences':dict(zip(['train','validation','test'],map(len,[train,valid,test]))),
       'split_predictions':dict(zip(['train','validation','test'],map(len,[ytr,yv,yt]))),
       'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [trainfile,testfile]},
       'pykt_commit':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),
       'pykt_dkt_sha256':hashlib.sha256(modelpath.read_bytes()).hexdigest(),
       'python':platform.python_version(),'torch':torch.__version__,'config':vars(args),
       'bkt':bkt,'dkt':{'implementation':'upstream pykt.models.dkt.DKT','history':history,'test':metrics(yt,dp),'seconds':time.time()-start}}
    (out/'metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    # Aggregate metrics only in tracked output; no student IDs exported.
    print(json.dumps({'BKT':bkt['test'],'DKT':result['dkt']['test']},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--dataset',required=True,choices=['assist2015','junyi2015'])
    p.add_argument('--data-dir',required=True);p.add_argument('--pykt-root',required=True);p.add_argument('--output',required=True)
    p.add_argument('--epochs',type=int,default=5);p.add_argument('--bkt-iterations',type=int,default=50)
    p.add_argument('--hidden',type=int,default=32);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--threads',type=int,default=4);p.add_argument('--valid-fold',type=int,default=0)
    a=p.parse_args()
    if a.epochs<1: p.error('epochs must be positive')
    run(a)
