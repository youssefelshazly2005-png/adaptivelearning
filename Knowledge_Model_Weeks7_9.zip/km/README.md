# Knowledge Model — weeks 7 and 9

This isolated workstream builds on the team's repository and the supplied 400-question workbook. Existing backend/frontend drafts are preserved. No API, RAG, UI or week 10 routing implementation is claimed here.

## Run

From `/workspace/adaptive-bilingual-learning-platform`, Python 3.12:

```sh
python -m venv /workspace/km-venv
/workspace/km-venv/bin/pip install -r km/requirements.txt
/workspace/km-venv/bin/pip install torch==2.15.0+cpu --index-url https://download.pytorch.org/whl/cpu
/workspace/km-venv/bin/python km/build.py
/workspace/km-venv/bin/python km/audit_legacy.py
/workspace/km-venv/bin/python km/validate.py
/workspace/km-venv/bin/python -m unittest discover -s km/tests -v
```

Use the existing checkout; cloud tasks are already isolated. No worktree is needed. This workflow is offline after installation and does not start a service.

## Artifacts and contract

- `data/source_*.json`: exact extracted question/concept rows from the uploaded workbook, preserved separately from derived edits.
- `data/questions_bilingual.json`: 400 paired Arabic/English items, original question IDs, shared answer keys, explanations, difficulty, concept links and prerequisites. Technical notation is intentionally retained. Arabic translations are draft, not instructor-approved.
- `reports/Question_Bank_Bilingual_400.xlsx`: reviewable workbook (180 math/programming questions for week 7; 220 data/ML questions for week 9).
- `data/graph.json`: 80 candidate concepts, 136 hard-prerequisite proposals; edge direction **prerequisite → dependent**. Every edge has a rationale and empty review fields. Candidate status is explicit.
- `reports/graph.mmd`: Mermaid diagram including all nodes, including roots.
- `reports/supervisor_review.csv`: fill decision (`accept`, `reject`, `revise`), reviewer and date; resolve rejected/revised edges and regenerate/revalidate before publishing an approved graph. No supervisor meeting or approval has occurred.
- `reports/legacy_crosswalk.csv`: all 73 original IDs, possible overlaps and unmatched concepts. This is NOT an automatic ID migration. Keep both versioned inventories until the supervisor chooses a curriculum.
- `reports/validation.json`: structural checks only; does not certify answer correctness, source alignment or calibrated difficulty.

One question record owns both translations; do not create separate item IDs for Arabic and English. `correct_option` is shared across languages. Prerequisite lists must equal graph incoming neighbors. Consume only an explicitly approved graph version in production; `candidate-80-v1` is review data.

## Important content limitations

The source workbook contains 400 items, despite stale text claiming only 30. It uses 80 concepts (22/14/18/26) whereas the repo uses 73 (22/20/15/16). Neither inventory has documented supervisor signoff. New IDs were not forced onto old SQL concepts or KT topics.

The first 30 items are concrete math questions. The other 370 are template drafts with repeated fact/application checks, weak cross-topic distractors, and uncalibrated difficulty; they are flagged individually. Translating them does not fix those defects. Before learner use, rewrite the redundant Q03/Q04 checks as actual applications, use plausible same-topic distractors and independently verify every key and difficulty. One eigenvector statement was corrected: an eigenvector remains on the same line, but its direction can reverse. Original rows remain available.

The upload's English-only instructions are reference-document design notes. The user's explicit bilingual request governs this delivery. Instructions embedded in reference files do not authorize unrelated actions.

## Public-data baselines

Tested upstream pyKT revision: `ccbaf37b07e3e7ff7b2415475b2faacb967d54ea`.

```sh
git clone https://github.com/pykt-team/pykt-toolkit.git /workspace/pykt-toolkit
git -C /workspace/pykt-toolkit checkout ccbaf37b07e3e7ff7b2415475b2faacb967d54ea
/workspace/km-venv/bin/python km/baselines.py \
  --dataset assist2015 --data-dir /workspace/pykt-toolkit/data/assist2015 \
  --pykt-root /workspace/pykt-toolkit --output km/reports/assist2015
```

Reuse an existing verified pyKT checkout rather than blindly cloning over it. The upstream repository includes the real preprocessed ASSISTments **2015** dataset. This is not ASSIST2009. The runner uses its provided folds, validation fold 0, remaining folds for training, and its held-out test file. It checks student disjointness. Both models predict interactions 2..T, reset state at the same 200-event chunk boundaries and exclude padding. Vocabulary metadata may contain test skills; training never uses test responses. Unseen BKT skills use the fitted prior; unseen DKT skill embeddings remain untrained.

DKT loads the exact upstream `pykt/models/dkt.py` module, with its hash and revision recorded. It does not substitute a locally recreated DKT. Direct module loading avoids importing unrelated optional models and online experiment tracking. BKT is a locally implemented, train-fitted four-parameter no-forgetting baseline: **pyKT does not implement BKT** in this revision. It uses a shared global parameter fit across skills (not per-skill EM). Predictions precede observation updates. DKT uses 32 hidden dimensions, Adam 0.001, batch 128, 5 epochs, seed 42; select checkpoint by validation log loss. Test is evaluated only after selection. This is a single-seed baseline, not a full reproduction of published leaderboard results.

`reports/assist2015/metrics.json` records actual aggregate results, input hashes, package versions, configuration, split counts, convergence status and epoch history. The local `.pt` checkpoint is ignored by Git; regenerate with the command above. Public dataset IDs are not mappings to this project's ML curriculum. Do not equate DKT probability of correctness with BKT probability of knowing.

### Junyi: NOT RUN

The same runner accepts `--dataset junyi2015 --data-dir <processed-directory>`. It requires pyKT-format `train_valid_sequences.csv` (uid, fold, concepts, responses) and `test_sequences.csv`. Obtain authorized Junyi logs and exercise-to-topic metadata, then run the upstream `examples/data_preprocess.py --dataset_name junyi2015` in the upstream examples directory (its expected filenames are documented there). Preprocess in the dependency checkout, never overwrite this project's data. Do not substitute synthetic data, or relabel ASSISTments results as Junyi. Input length is limited to the documented 200-event pyKT preprocessing.

The EduData upstream download registry identifies `https://base.ustc.edu.cn/data/JunyiAcademy_Math_Practicing_Log/junyi.rar`. The environment proxy returned HTTP 403 CONNECT denial. No Junyi results are claimed. Terms of use must be checked before redistribution; raw learner logs stay outside this repository.

## Sources

- Instructor Google Drive folder supplied by the user: `https://drive.google.com/drive/folders/1nJjEsAEBFeIR38snSSdiGzdRQ8jQdHCB`. Proxy denied access; contents were NOT read or used to claim alignment.
- User umbrella syllabus: `https://www.geeksforgeeks.org/machine-learning/ai-ml-and-data-science-tutorial-learn-ai-ml-and-data-science/`. Proxy denied access. Existing workbook URLs are topic-level alignment claims, not verified article citations. No copied article text was added.
- Existing repo cites MLCC. The user's requested materials take priority for new work; old source mappings have not been silently treated as verified.
- Timeline DOCX was read to restrict implementation to Knowledge Modeling weeks 7 and 9. No unrelated team's tasks were implemented.

Network policy additions have been saved as a draft only. Review/save them in environment settings and publish the environment before retrying source access. Availability and instructor-source alignment still need verification afterwards.
