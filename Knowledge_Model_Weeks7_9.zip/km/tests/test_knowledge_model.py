import copy
import importlib.util
import json
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def module(name):
    s=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
validate=module('validate').validate
bkt=module('baselines').bkt_predict

class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        self.g=json.loads((ROOT/'data/graph.json').read_text());self.q=json.loads((ROOT/'data/questions_bilingual.json').read_text())
    def test_complete_bank(self):
        r=validate(self.g,self.q);self.assertEqual(r['questions'],400);self.assertEqual(r['concepts'],80)
    def test_cycle_rejected(self):
        self.g['edges'].append({'prerequisite_id':'MATH_002','concept_id':'MATH_001'})
        with self.assertRaises(ValueError):validate(self.g,self.q)
    def test_unknown_endpoint(self):
        self.g['edges'][0]['concept_id']='UNKNOWN'
        with self.assertRaises(ValueError):validate(self.g,self.q)
    def test_no_self_loop(self):
        self.g['edges'][0]['concept_id']=self.g['edges'][0]['prerequisite_id']
        with self.assertRaises(ValueError):validate(self.g,self.q)
    def test_duplicate_id_rejected(self):
        self.q[1]['question_id']=self.q[0]['question_id']
        with self.assertRaises(ValueError):validate(self.g,self.q)
    def test_translation_required(self):
        self.q[0]['translations']['ar']['question_text']=''
        with self.assertRaises(ValueError):validate(self.g,self.q)
    def test_answer_key_required(self):
        self.q[0]['correct_option']='E'
        with self.assertRaises(ValueError):validate(self.g,self.q)
    def test_prerequisite_sync(self):
        self.q[0]['prerequisite_ids']=['MATH_002']
        with self.assertRaises(ValueError):validate(self.g,self.q)
    def test_gold_requires_approval(self):
        self.g['status']='gold'
        with self.assertRaises(ValueError):validate(self.g,self.q)
    def test_bkt_no_target_leakage(self):
        import numpy as np
        q=np.array([[0,0,0]]);r=np.array([[1,0,1]]);m=np.array([[False,True,True]])
        a=bkt([.2,.1,.2,.1],(q,r,m),1);r[0,1]=1;b=bkt([.2,.1,.2,.1],(q,r,m),1)
        self.assertAlmostEqual(a[0],b[0]);self.assertNotAlmostEqual(a[1],b[1])
    def test_bkt_distinct_skill_state(self):
        import numpy as np
        q=np.array([[0,1]]);r=np.array([[1,1]]);m=np.array([[False,True]])
        p=bkt([.2,.1,.2,.1],(q,r,m),2)
        self.assertAlmostEqual(p[0],.2*.9+.8*.2)
    def test_next_response_alignment_and_padding(self):
        import numpy as np
        arr=module('baselines').arrays([('s',0,np.array([2,3,2]),np.array([1,0,1]))])
        self.assertEqual(arr[2].sum(),2);self.assertFalse(arr[2][0,0]);self.assertFalse(arr[2][0,3:].any())

if __name__=='__main__':unittest.main()
