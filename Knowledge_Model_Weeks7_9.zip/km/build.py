"""Rebuild bilingual draft artifacts without changing the source workbook records."""
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'

def load(name):
    return json.loads((DATA / name).read_text())

def write(name, value):
    (DATA / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def build():
    concepts, questions = load('source_concepts.json'), load('source_questions.json')
    prereqs = load('prerequisites.json')
    ar = {r[0]: r[1:] for r in csv.reader((DATA / 'arabic.tsv').open(), delimiter='\t')}
    math = load('math_ar.json')
    translations = dict(math['options'])
    for c in concepts[6:]:
        rows = [q for q in questions if q['concept_id'] == c['concept_id']]
        for q, t in zip([rows[0], rows[1], rows[4]], ar[c['concept_id']][1:]):
            translations[q['option_' + q['correct_option'].lower() + '_en']] = t
    result = []
    for i,q in enumerate(questions):
        cid = q['concept_id']; n = int(q['question_id'][-2:]); name = ar[cid][0]
        en_options = {a.upper(): q['option_' + a + '_en'] for a in 'abcd'}
        # Correct a mathematical imprecision while preserving the original in source_questions.json.
        for key,value in en_options.items():
            if value == 'An eigenvector keeps its direction under a matrix transformation':
                en_options[key] = 'A nonzero eigenvector remains on the same line after transformation (its direction can reverse)'
        ar_options = {a.upper(): translations.get(q['option_'+a+'_en'], q['option_'+a+'_en']) for a in 'abcd'}
        if i < 30:
            prompt, explanation = math['prompts'][i], math['explanations'][i]
        else:
            prompt = {
                1: f'أي عبارة عن {name} صحيحة؟',
                2: f'أي مهمة تمثل استخدامًا مناسبًا لمفهوم {name}؟',
                3: f'يدرس متعلم مفهوم {name}. أي ملاحظة ينبغي أن يتوقعها؟',
                4: f'أي إجراء أنسب عند تطبيق {name} في مسار تمهيدي للتعلم الآلي؟',
                5: f'يطبق طالب مفهوم {name}. أي خطأ مفاهيمي ينبغي للمراجع اكتشافه؟'
            }[n]
            explanation = ('هذا خطأ ينبغي تجنبه: ' if n == 5 else 'الإجابة المتوافقة مع المفهوم: ') + ar_options[q['correct_option']]
        flags = [] if i < 30 else ['template_item', 'weak_cross_topic_distractors', 'duplicate_learning_check', 'difficulty_unvalidated']
        result.append({
            'question_id':q['question_id'], 'concept_id':cid, 'layer':q['layer'],
            'difficulty': q['difficulty'], 'correct_option':q['correct_option'],
            'translations':{'en':{'question_text':q['question_en'],'options':en_options,'explanation':q['explanation_en'].replace('An eigenvector keeps its direction under a matrix transformation', 'A nonzero eigenvector remains on the same line after transformation (its direction can reverse)')},
                            'ar':{'question_text':prompt,'options':ar_options,'explanation':explanation}},
            'learning_objective':q['learning_objective'], 'prerequisite_ids':prereqs[cid],
            'reference_url':q['reference_url'], 'source_status':'topic_alignment_only_unverified',
            'review_status':'pending_subject_and_bilingual_review', 'quality_flags':flags,
            'kg_version':'candidate-80-v1'})
    nodes = [{'concept_id':c['concept_id'],'name_en':c['name'],'name_ar':ar[c['concept_id']][0],
              'layer':c['layer'],'learning_objective':c['learning_objective'],
              'reference_url':c['reference_url'], 'review_status':'pending_supervisor'} for c in concepts]
    names = {c['concept_id']:c['name'] for c in concepts}
    edges = [{'edge_id':f'PRE_{p}_{c}', 'prerequisite_id':p, 'concept_id':c,
              'edge_type':'hard_prerequisite', 'status':'candidate', 'source':'manual_curriculum_proposal',
              'rationale':f'{names[p]} supplies foundational knowledge for {names[c]}.',
              'reviewer':None,'decision':None,'reviewed_at':None} for c,ps in prereqs.items() for p in ps]
    graph = {'kg_version':'candidate-80-v1','status':'candidate_not_gold','edge_direction':'prerequisite -> dependent',
             'supervisor_approved':False, 'concepts':nodes,'edges':edges}
    write('graph.json',graph);write('questions_bilingual.json',result)
    with (ROOT/'reports/supervisor_review.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(edges[0]));w.writeheader();w.writerows(edges)
    mermaid = 'flowchart LR\n' + ''.join(f'  {c["concept_id"]}["{c["concept_id"]}: {c["name_en"]}"]\n' for c in nodes)
    mermaid += ''.join(f'  {e["prerequisite_id"]} --> {e["concept_id"]}\n' for e in edges)
    (ROOT/'reports/graph.mmd').write_text(mermaid)
    write('provenance.json',{'workbook':'Adaptive_Learning_Question_Bank_All_400_Draft.xlsx',
        'source_questions_sha256':hashlib.sha256((DATA/'source_questions.json').read_bytes()).hexdigest(),
        'legacy_concepts':73,'candidate_concepts':len(nodes),'questions':len(result),'edges':len(edges),
        'layers':dict(Counter(q['layer'] for q in result)),
        'note':'User requested bilingual delivery. Workbook English-only directions describe its original design; they do not override the user request.'})
    export_xlsx(result,nodes,edges)
    print(f'Built {len(nodes)} concepts, {len(edges)} candidate edges, {len(result)} bilingual draft questions')

def export_xlsx(questions,concepts,edges):
    import openpyxl
    w=openpyxl.Workbook();s=w.active;s.title='Questions'
    s.append(['question_id','concept_id','layer','difficulty','question_en','question_ar',
              *[f'option_{a}_{lang}' for lang in ['en','ar'] for a in 'ABCD'],
              'correct_option','explanation_en','explanation_ar','prerequisites','review_status','quality_flags','reference_url'])
    for q in questions:
        t=q['translations'];s.append([q['question_id'],q['concept_id'],q['layer'],q['difficulty'],t['en']['question_text'],t['ar']['question_text'],
            *[t[l]['options'][a] for l in ['en','ar'] for a in 'ABCD'],q['correct_option'],t['en']['explanation'],t['ar']['explanation'],
            ','.join(q['prerequisite_ids']),q['review_status'],','.join(q['quality_flags']),q['reference_url']])
    s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
    for name,rows in [('Concepts',concepts),('Prerequisites',edges)]:
        s=w.create_sheet(name);s.append(list(rows[0]));
        for r in rows:s.append(list(r.values()))
    s=w.create_sheet('Read me');s.append(['Status','400 bilingual draft MCQs; NOT expert-approved.'])
    s.append(['Quality','370 template items need substantive rewriting and stronger distractors.'])
    s.append(['Graph','Candidate only; use supervisor_review.csv for decisions before declaring a gold graph.'])
    w.save(ROOT/'reports/Question_Bank_Bilingual_400.xlsx')

if __name__=='__main__':build()
