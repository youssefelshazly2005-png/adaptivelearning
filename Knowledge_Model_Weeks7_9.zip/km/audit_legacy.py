"""Report legacy inventory differences; never silently migrate legacy IDs."""
import csv,json,re
from pathlib import Path
R=Path(__file__).resolve().parent
mapping=json.loads((R/'data/legacy_map.json').read_text())
text=(R.parent/'knowledge-model/concepts/concept_list.md').read_text()
rows=[]
for line in text.splitlines():
    cols=[x.strip() for x in line.split('|')]
    if len(cols)>4 and re.fullmatch(r'(M|P|D|ML)\d{2}',cols[1]):
        cid=cols[1];targets=mapping[cid]
        rows.append({'legacy_id':cid,'legacy_name':cols[2],'candidate_ids':';'.join(targets),
                     'status':'partial_overlap_requires_review' if targets else 'no_direct_equivalent_keep_legacy',
                     'migration_approved':False})
with (R/'reports/legacy_crosswalk.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
assert len(rows)==73
print('Audited 73 legacy concepts; no ID migration performed')
